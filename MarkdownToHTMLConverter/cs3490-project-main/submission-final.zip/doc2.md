# The Top 3 Programming Languages

1. Python
2. JavaScript
3. GoLang
