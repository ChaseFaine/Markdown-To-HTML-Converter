# This is my first header

## This tests **bold** text

## This tests *italic* text

## This tests ***bold and italic*** text

## This tests `preformatted` text

This is ~~not~~ a [normal](https://www.google.com/search?q=normal) paragraph. I can make things **bold** or *italic* or ***both***. I can even have `preformatted` text. Isn't markdown cool?!

> This will be an easy project. Markdown is simple to parse... Until it isn't.

- [] I am not checked
- [ ] I am also not checked
- [x] I am checked

![Pikachu](https://static.zerochan.net/Pikachu.600.1452733.jpg)

<!-- 
this will not be seen
-->
